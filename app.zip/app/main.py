"""FastAPI application entry point.

Builds the application, wires configuration, and mounts the API routers. The mode API
(RAG-014) is the one place this application reaches the pipeline: every request goes through
:class:`~app.web.service.ModeRunner`, which owns a single RAG-013 mode service, so no
retrieval, generation, citation or discovery logic lives here or in the frontend.

The static UI is mounted last, at ``/``, so ``/api/...`` and ``/health`` are matched by their
routers before the catch-all static handler is consulted.
"""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.api.errors import install_error_handlers
from app.api.health import router as health_router
from app.api.modes import router as modes_router
from app.api.status import router as status_router
from app.config import Settings, get_settings
from app.web import STATIC_DIR
from app.web.service import ModeRunner


def create_app(
    *,
    settings: Settings | None = None,
    mode_runner: ModeRunner | None = None,
    mount_ui: bool = True,
) -> FastAPI:
    """Construct and configure the FastAPI application.

    ``mode_runner`` can be injected (the ``python -m app.web`` entry point passes the one
    configured from its command line); otherwise the application builds its own, and the
    pipeline it holds is built on the first request and closed when the server stops.
    """
    settings = settings or get_settings()
    runner = mode_runner or ModeRunner(settings=settings)

    application = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        debug=settings.debug,
        lifespan=_lifespan(runner),
    )
    application.state.mode_runner = runner
    application.state.settings = settings
    application.include_router(health_router)
    application.include_router(modes_router)
    application.include_router(status_router)
    install_error_handlers(application)
    if mount_ui:
        application.mount(
            "/", StaticFiles(directory=str(STATIC_DIR), html=True), name="ui"
        )
    return application


def _lifespan(runner: ModeRunner):
    """Close the pipeline the runner built when the application stops."""

    async def lifespan(_: FastAPI):
        yield
        runner.close()

    return lifespan


app = create_app()
