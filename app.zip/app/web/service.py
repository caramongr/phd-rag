"""The web process's mode service (RAG-014).

A web server is not a CLI: the process lives for hours, and the expensive part of the
pipeline (BGE-M3, the cross-encoder, the Qdrant client) must be built once and reused. This
module owns exactly one :class:`~app.modes.service.ModeService`, builds it on first use, and
runs one request at a time.

Why one at a time: the service holds two local models and a local Qdrant store, and a local
Qdrant store may be opened by one client per process. Two concurrent runs would be two
concurrent model forwards on the same objects and one store shared by two callers through
different code paths. The lock is deliberate and cheap — the pipeline is compute bound, so
serialising runs costs almost nothing and removes a whole class of failures.

Nothing here knows about HTTP. The API layer converts requests into calls and results into
transport; the runner only owns the service and its lifetime.
"""

from __future__ import annotations

import threading
from typing import Any, Callable, Mapping

from app.config import Settings, get_settings
from app.modes.factory import build_mode_service
from app.modes.models import ModeResult

#: Builds a mode service from settings. Injectable so tests never touch a real model.
ServiceFactory = Callable[..., Any]


class ModeRunner:
    """One lazily built :class:`ModeService`, used by one run at a time."""

    def __init__(
        self,
        *,
        settings: Settings | None = None,
        service_factory: ServiceFactory | None = None,
        model: str | None = None,
        rerank: bool = True,
    ) -> None:
        self.settings = settings or get_settings()
        self._factory = service_factory or build_mode_service
        self._model = model
        self._rerank = rerank
        self._service: Any | None = None
        self._lock = threading.Lock()
        self._builds = 0

    # --- lifecycle ------------------------------------------------------------
    @property
    def is_built(self) -> bool:
        """Whether the pipeline has been built (status must not build it)."""
        return self._service is not None

    @property
    def build_count(self) -> int:
        """How many times the service was built (should stay at 1)."""
        return self._builds

    def service(self) -> Any:
        """The mode service, built on first use."""
        with self._lock:
            return self._ensure_service()

    def _ensure_service(self) -> Any:
        if self._service is None:
            self._service = self._factory(
                self.settings, model=self._model, rerank=self._rerank
            )
            self._builds += 1
        return self._service

    def retrieval_service(self) -> Any | None:
        """The RAG-009 service once a run has built it, so status can reuse its client.

        ``ModeService`` exposes it as a property, so this reads it as a value when it is not
        callable — asking the service for something is not the same as asking it to build it.
        """
        service = self._service
        if service is None:
            return None
        attribute = getattr(service, "retrieval_service", None)
        if attribute is None:
            return None
        return attribute() if callable(attribute) else attribute

    def probe(self) -> bool:
        """Take the run lock briefly, so a status probe cannot collide with a run.

        A local Qdrant store is opened once per process: if a run is in flight, a probe must
        report "in use" instead of opening a second client and breaking the run.
        """
        return self._lock.acquire(blocking=False)

    def probe_done(self) -> None:
        """Release the lock taken by :meth:`probe`."""
        self._lock.release()

    def close(self) -> None:
        """Close the pipeline this runner built, if any."""
        with self._lock:
            if self._service is not None:
                close = getattr(self._service, "close", None)
                if callable(close):
                    close()
                self._service = None

    def __enter__(self) -> "ModeRunner":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    # --- the one call the API makes -------------------------------------------
    def run(
        self,
        mode: str,
        query: str,
        *,
        options: Mapping[str, Any] | None = None,
    ) -> ModeResult:
        """Run one mode for one query, serialised against other runs."""
        with self._lock:
            service = self._ensure_service()
            return service.run_mode(mode, query, **dict(options or {}))


__all__ = ["ModeRunner", "ServiceFactory"]
